const hre = require('hardhat');
const { readDeployment, requireNetwork } = require('./deployment-targets');

async function main() {
  await requireNetwork(hre);
  const { ethers, network } = hre;
  const walletAddress = ethers.getAddress(process.env.DEMO_WALLET_ADDRESS || '');
  if (walletAddress === ethers.ZeroAddress) throw new Error('Supply a public Ethereum wallet address.');

  const { TestToken } = readDeployment(network.name);
  if (await ethers.provider.getCode(TestToken) === '0x') {
    throw new Error('TestToken has no code at the recorded address. Check the deployment record.');
  }
  const [owner] = await ethers.getSigners();
  if (!owner) throw new Error('Set DEPLOYER_PRIVATE_KEY in the project .env.');
  const token = await ethers.getContractAt('TestToken', TestToken, owner);
  if (await token.owner() !== await owner.getAddress()) {
    throw new Error('TestToken minting requires the token owner.');
  }
  await (await token.mint(walletAddress, ethers.parseUnits('1000', await token.decimals()))).wait();
  console.log(`Minted 1000 DST to ${walletAddress}`);

  if (network.name === 'localhost') {
    await (await owner.sendTransaction({ to: walletAddress, value: ethers.parseEther('1') })).wait();
    console.log(`Sent 1 local test ETH to ${walletAddress}`);
  }
}

main().catch((error) => {
  console.error(error.shortMessage || error.message);
  process.exitCode = 1;
});
