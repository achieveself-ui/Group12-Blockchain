const hre = require('hardhat');
const { requireNetwork, writeDeployment } = require('./deployment-targets');

async function deploy(name, args = []) {
  const contract = await hre.ethers.deployContract(name, args);
  const receipt = await contract.deploymentTransaction().wait();
  return { contract, address: await contract.getAddress(), receipt };
}

async function main() {
  const { chainId } = await requireNetwork(hre);
  const networkName = hre.network.name;
  const [deployer] = await hre.ethers.getSigners();
  if (!deployer) throw new Error('Set DEPLOYER_PRIVATE_KEY in the project .env.');

  const asset = await deploy('TestToken');
  const pool = await deploy('SecurePool');
  const share = await deploy('PoolShareToken', [pool.address]);
  const initialization = await (await pool.contract.initialize(asset.address, share.address)).wait();

  const contracts = {
    TestToken: asset.address,
    SecurePool: pool.address,
    PoolShareToken: share.address,
  };
  const receipts = {
    TestToken: asset.receipt,
    SecurePool: pool.receipt,
    PoolShareToken: share.receipt,
    initialize: initialization,
  };
  const transactions = Object.fromEntries(Object.entries(receipts).map(([name, receipt]) => [
    name,
    {
      hash: receipt.hash,
      blockNumber: receipt.blockNumber,
      ...(networkName === 'sepolia' ? { explorer: `https://sepolia.etherscan.io/tx/${receipt.hash}` } : {}),
    },
  ]));
  const filename = writeDeployment(networkName, {
    network: networkName,
    chainId: chainId.toString(),
    deployedAt: new Date().toISOString(),
    deployer: await deployer.getAddress(),
    contracts,
    transactions,
  });
  for (const [name, address] of Object.entries(contracts)) console.log(`${name}: ${address}`);
  console.log(`Deployment saved to ${filename}`);
}

main().catch((error) => {
  console.error(error.shortMessage || error.message);
  process.exitCode = 1;
});
