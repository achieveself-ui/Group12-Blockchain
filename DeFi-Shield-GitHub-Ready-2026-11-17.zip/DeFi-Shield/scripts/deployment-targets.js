const path = require('node:path');
const fs = require('node:fs');
const { getAddress } = require('ethers');

const projectRoot = path.resolve(__dirname, '..');
const deploymentDir = path.join(projectRoot, 'deployments');
const targets = {
  localhost: { chainId: 31337n, mode: 'hardhat', record: 'local.json' },
  sepolia: { chainId: 11155111n, mode: 'sepolia', record: 'sepolia.json' },
};

function getTarget(networkName) {
  if (!Object.hasOwn(targets, networkName)) {
    throw new Error('Select localhost or sepolia.');
  }
  return targets[networkName];
}

async function requireNetwork(hre) {
  const networkName = hre.network.name;
  const target = getTarget(networkName);
  const actual = await hre.ethers.provider.getNetwork();
  if (actual.chainId !== target.chainId) {
    throw new Error(`Expected chain ID ${target.chainId}, got ${actual.chainId}.`);
  }
  return target;
}

function writeDeployment(networkName, deployment) {
  const filename = path.join(deploymentDir, getTarget(networkName).record);
  fs.mkdirSync(deploymentDir, { recursive: true });
  fs.writeFileSync(`${filename}.tmp`, JSON.stringify(deployment, null, 2) + '\n');
  fs.renameSync(`${filename}.tmp`, filename);
  return path.relative(projectRoot, filename);
}

function readDeployment(networkName) {
  const target = getTarget(networkName);
  let filename = path.join(deploymentDir, target.record);
  if (networkName === 'sepolia' && !fs.existsSync(filename)) {
    filename = path.join(deploymentDir, 'sepolia-existing.json');
  }
  if (!fs.existsSync(filename)) {
    throw new Error(`Missing ${path.relative(projectRoot, filename)}. Run npm run deploy:local first.`);
  }
  const record = JSON.parse(fs.readFileSync(filename, 'utf8'));
  if (record.network !== networkName || String(record.chainId) !== String(target.chainId)) {
    throw new Error(`Deployment record has the wrong network: ${path.relative(projectRoot, filename)}.`);
  }
  const { TestToken, SecurePool, PoolShareToken } = record.contracts;
  return {
    TestToken: getAddress(TestToken),
    SecurePool: getAddress(SecurePool),
    PoolShareToken: getAddress(PoolShareToken),
  };
}

module.exports = { getTarget, projectRoot, requireNetwork, readDeployment, writeDeployment };
