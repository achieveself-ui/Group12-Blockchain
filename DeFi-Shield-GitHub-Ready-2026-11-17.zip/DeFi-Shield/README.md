# DeFi Shield

DeFi Shield 是一个资金池安全教学项目。使用 MetaMask 连接双语 React 前端后，可以把测试代币 DST 存入 SecurePool、按 1:1 获得 DSPS 凭证，再赎回 DST。前端在交易确认后读取链上余额和凭证总量。

| 运行方式 | Chain ID | 前端网址 |
| --- | --- | --- |
| Hardhat 本地修复版和只读安全教学 | 31337 | `http://localhost:5175/` |
| Sepolia 修复版 | 11155111 | `http://localhost:5173/` |

## 项目目录

| 路径 | 内容 |
| --- | --- |
| `contracts/` | TestToken、PoolShareToken、SecurePool 及测试专用代币 |
| `scripts/` | 部署和初始化、测试账户发币、同步前端地址 |
| `deployments/` | E 提供的 Sepolia 地址记录，以及运行脚本后生成的部署记录 |
| `test/` | SecurePool 自动化回归测试 |
| `frontend/` | React、TypeScript、ethers.js 合约服务、ABI、测试证据和前端启动说明 |
| `docs/` | [部署与验证记录](docs/verification.md) |
| `hardhat.config.js` | Hardhat 网络配置及 Solidity 编译配置 |

## 1. 安装

使用 Node.js 22.16.0 或更新的 22.x 版本、npm 和浏览器的 MetaMask 扩展。解压后，在项目根目录 `DeFi-Shield/` 打开 CMD。根目录能看到 `hardhat.config.js`。

```cmd
npm ci
npm --prefix frontend ci
```

编译和运行测试。

```cmd
npm run compile
npm test
```

## 2. 在本地部署并演示

**CMD 窗口 1**，启动节点并保持窗口运行。

```cmd
npm run node
```

**CMD 窗口 2**，进入同一项目根目录并部署。脚本部署测试代币、修复池和凭证代币，初始化资金池，把地址写入 `deployments/local.json`，并生成 `frontend/.env.hardhat.local`。

```cmd
npm run deploy:local
```

在 MetaMask 中添加自定义网络。

| 字段 | 值 |
| --- | --- |
| 网络名称 | Hardhat Local |
| RPC URL | `http://127.0.0.1:8545` |
| 链 ID | `31337` |
| 货币符号 | ETH |

复制 MetaMask 的账户公开地址。把下方的占位文字换成该地址，然后在 **CMD 窗口 2** 运行。脚本向该账户转入 1 本地测试 ETH 和 1,000 DST。

```cmd
set "DEMO_WALLET_ADDRESS=替换成你的0x钱包地址"
npm run fund:local
npm run dev:local
```

打开 `http://localhost:5175/`，连接 MetaMask 并选 Hardhat Local。首次存入 1 DST 时，如果额度不足，依次确认授权和存款。确认后可看到池内资产和 DSPS 增加 1。选择「修复版操作」赎回 1 DSPS，确认凭证销毁、DST 退回。可在「本地安全教学」查看池资产、凭证供应量和资产覆盖情况。

Hardhat 节点关闭后，本地链状态会重置。重新启动节点时，重新运行部署和发币命令，再启动前端。

## 3. 使用 Sepolia 上已有的修复版

```cmd
npm run dev:sepolia
```

打开 `http://localhost:5173/`，连接钱包并选择 Sepolia 测试网。前端默认读取 [团队部署记录](deployments/sepolia-existing.json) 中的地址。发交易需要 Sepolia 测试 ETH，存款还需要部署记录中对应的 DST。

### 在 Sepolia 部署新的修复池

在项目根目录复制配置模板。

```cmd
copy .env.example .env
notepad .env
```

填写 `SEPOLIA_RPC_URL` 和有 Sepolia 测试 ETH 的部署账户的 `DEPLOYER_PRIVATE_KEY`。如要给演示账户发 DST，在同一文件中填写公开地址 `DEMO_WALLET_ADDRESS`。根目录的 `.env` 由 `.gitignore` 排除。

```cmd
npm run deploy:sepolia
npm run mint:sepolia
npm run dev:sepolia
```

`mint:sepolia` 由 TestToken 所有者运行。新部署的公开地址、交易哈希、区块号、时间和浏览器链接写入 `deployments/sepolia.json`，前端地址写入 `frontend/.env.sepolia.local`。

## 4. 构建前端并上传 GitHub

```cmd
npm run build:sepolia
npm run build:local
```

Sepolia 构建文件在 `frontend/dist/sepolia/`，可以发布到静态站点。先完成本地部署，再运行本地构建，产物位于 `frontend/dist/hardhat/`。

上传源代码时，把解压后 `DeFi-Shield/` 内的文件和文件夹放到 GitHub 仓库根目录，保留 `.gitignore`、`.nvmrc`、`.env.example` 和两个锁文件。部署到 Sepolia 与发布前端页面是两个步骤，所需命令见上文。

## 本次验收范围

本地安全教学只读展示 SecurePool 数据和修复说明。两版实验对比数据和静态扫描报告待接入。测试与报告页面提供本次打包实际运行的 SecurePool 回归输出。见 [部署与验证记录](docs/verification.md)。
