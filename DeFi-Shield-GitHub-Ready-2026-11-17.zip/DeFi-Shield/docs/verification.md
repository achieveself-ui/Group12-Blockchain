# 部署与验证记录

打包日期为 2026 年 11 月 17 日。合约沿用 E 版的 TestToken、PoolShareToken 和 SecurePool。双语前端使用同一套合约交互服务连接本地链和 Sepolia。

## 本地验证

本次验证环境使用 Node.js 24.22.1、Hardhat 2.26.3、Solidity 0.8.24 和 Vite 7.3.7。仓库锁文件记录了依赖版本。验证环境使用已有的对应版本依赖，离线缓存中的安装文件不全。安装步骤见根目录 README。

| 验证项 | 结果 |
| --- | --- |
| `npm run compile` | 15 个 Solidity 文件编译成功 |
| `npm test` | SecurePool 15 项通过。见 [测试输出](../frontend/public/evidence/secure-pool-test.txt) |
| `npm run deploy:local` | 在临时 Hardhat 链部署三份合约、初始化资金池并同步前端地址 |
| `npm run fund:local` | 分配 1,000 DST 和 1 本地测试 ETH |
| 前端合约服务 | 通过本地 RPC 验证授权、存款、确认后读数、赎回及再次读数 |
| `npm run build:local` 与 `npm run build:sepolia` | 两个模式均构建成功 |

前端合约服务验证使用连接到本地 Hardhat 的测试钱包接口。实际 MetaMask 弹窗交互以演示机器上的钱包为准。

| 操作阶段 | 钱包 DST | 池内 DST | 用户 DSPS | DSPS 总量 |
| --- | ---: | ---: | ---: | ---: |
| 发币后 | 1,000 | 0 | 0 | 0 |
| 存入 1 DST 后 | 999 | 1 | 1 | 1 |
| 赎回 1 DSPS 后 | 1,000 | 0 | 0 | 0 |

## Sepolia

内置地址来自 E 的 [现有部署记录](../deployments/sepolia-existing.json)。本次验证完成 Sepolia 前端构建。新部署与链上交易验证可按 [README](../README.md) 在 Sepolia 测试网执行。

## 教学与报告页面

本地安全教学读取 SecurePool 的真实数据，展示资产覆盖和权限设计。两版对比实验数据及 Solidity 静态扫描报告待接入。
