import { BrowserProvider, Contract, Interface, formatUnits, getAddress, parseUnits, type Eip1193Provider } from 'ethers';
import { assetAddress, expectedChainId, poolAbi, poolAddress, shareAddress as expectedShareAddress, tokenAbi } from '../contracts/config';
import type { CopyKey } from '../i18n';

export class PoolError extends Error {
  constructor(public readonly messageKey: CopyKey, public readonly params: Record<string, string | number> = {}) {
    super(messageKey);
    this.name = 'PoolError';
  }
}

declare global {
  interface Window {
    ethereum?: Eip1193Provider & {
      on?: (event: string, listener: () => void) => void;
      removeListener?: (event: string, listener: () => void) => void;
    };
  }
}

export type Snapshot = {
  assetBalance: bigint;
  poolBalance: bigint;
  shareBalance: bigint;
  totalSupply: bigint;
  allowance: bigint;
  assetDecimals: number;
  shareDecimals: number;
  assetSymbol: string;
  shareSymbol: string;
  paused: boolean;
};

export type TxPhase = 'wallet' | 'pending' | 'success';
export type TxUpdate = (phase: TxPhase, hash?: string) => void;

export async function walletState(requestAccounts = false) {
  if (!window.ethereum) throw new PoolError('error.walletMissing');
  const provider = new BrowserProvider(window.ethereum, undefined, { cacheTimeout: -1 });
  const accounts = await provider.send(requestAccounts ? 'eth_requestAccounts' : 'eth_accounts', []);
  const network = await provider.getNetwork();
  return { provider, account: (accounts[0] as string | undefined) ?? '', chainId: Number(network.chainId) };
}

export function requireNetwork(chainId: number) {
  if (chainId !== expectedChainId) throw new PoolError('error.wrongNetwork', { chainId: expectedChainId });
}

export async function readSnapshot(provider: BrowserProvider, account: string): Promise<Snapshot> {
  requireNetwork(Number((await provider.getNetwork()).chainId));
  const [poolCode, assetCode] = await Promise.all([provider.getCode(poolAddress), provider.getCode(assetAddress)]);
  if (poolCode === '0x' || assetCode === '0x') throw new PoolError('error.contractMissing');
  const pool = new Contract(poolAddress, poolAbi, provider);
  const asset = new Contract(assetAddress, tokenAbi, provider);
  const [initialized, shareAddress, deployedAssetAddress] = await Promise.all([pool.initialized(), pool.shareToken(), pool.assetToken()]);
  if (!initialized) throw new PoolError('error.uninitialized');
  if (getAddress(deployedAssetAddress) !== getAddress(assetAddress)) throw new PoolError('error.assetMismatch');
  if (expectedShareAddress && getAddress(shareAddress) !== getAddress(expectedShareAddress)) throw new PoolError('error.shareMismatch');
  if (await provider.getCode(shareAddress) === '0x') throw new PoolError('error.shareMissing');
  const share = new Contract(shareAddress, tokenAbi, provider);
  const [assetBalance, poolBalance, shareBalance, totalSupply, allowance, assetDecimals, shareDecimals, assetSymbol, shareSymbol, paused] = await Promise.all([
    asset.balanceOf(account), pool.getPoolBalance(), share.balanceOf(account), share.totalSupply(),
    asset.allowance(account, poolAddress), asset.decimals(), share.decimals(), asset.symbol(), share.symbol(), pool.paused(),
  ]);
  return { assetBalance, poolBalance, shareBalance, totalSupply, allowance, assetDecimals: Number(assetDecimals), shareDecimals: Number(shareDecimals), assetSymbol, shareSymbol, paused };
}

export function displayAmount(value: bigint, decimals: number) {
  return formatUnits(value, decimals);
}

export function inputAmount(input: string, decimals: number) {
  if (!/^(?:0|[1-9]\d*)(?:\.\d+)?$/.test(input.trim())) throw new PoolError('error.invalidAmount');
  let amount: bigint;
  try { amount = parseUnits(input.trim(), decimals); }
  catch { throw new PoolError('error.invalidAmount'); }
  if (amount <= 0n) throw new PoolError('error.zeroAmount');
  return amount;
}

export async function deposit(provider: BrowserProvider, account: string, amount: bigint, onUpdate: TxUpdate) {
  const signer = await provider.getSigner(account);
  const token = new Contract(assetAddress, tokenAbi, signer);
  const pool = new Contract(poolAddress, poolAbi, signer);
  if ((await token.allowance(account, poolAddress)) < amount) {
    onUpdate('wallet');
    const approval = await token.approve(poolAddress, amount);
    onUpdate('pending', approval.hash);
    const receipt = await approval.wait();
    if (receipt?.status !== 1) throw new PoolError('error.approvalReverted');
  }
  onUpdate('wallet');
  const transaction = await pool.deposit(amount);
  onUpdate('pending', transaction.hash);
  const receipt = await transaction.wait();
  if (receipt?.status !== 1) throw new PoolError('error.depositReverted');
  onUpdate('success', transaction.hash);
}

export async function redeem(provider: BrowserProvider, account: string, amount: bigint, onUpdate: TxUpdate) {
  const pool = new Contract(poolAddress, poolAbi, await provider.getSigner(account));
  onUpdate('wallet');
  const transaction = await pool.redeem(amount);
  onUpdate('pending', transaction.hash);
  const receipt = await transaction.wait();
  if (receipt?.status !== 1) throw new PoolError('error.redeemReverted');
  onUpdate('success', transaction.hash);
}

export function classifyError(error: unknown) {
  if (error instanceof PoolError) {
    return {
      labelKey: error.messageKey.endsWith('Reverted') ? 'status.reverted' as const : 'status.failed' as const,
      messageKey: error.messageKey,
      params: error.params,
    };
  }
  const e = error as { code?: string | number; data?: string; shortMessage?: string; message?: string; info?: { error?: { code?: number; data?: string } } };
  if (e.code === 4001 || e.code === 'ACTION_REJECTED' || e.info?.error?.code === 4001) return { labelKey: 'status.rejected' as const, messageKey: 'status.rejectedMessage' as const };
  if (e.code === 'CALL_EXCEPTION' || /revert/i.test(e.shortMessage ?? e.message ?? '')) {
    const descriptions: Record<string, CopyKey> = {
      NotInitialized: 'error.uninitialized', ZeroAmount: 'error.zeroAmount',
      InsufficientShares: 'error.lowShareBalance', InsufficientPoolAssets: 'error.lowPoolBalance',
      UnsupportedAssetTransfer: 'error.unsupportedTransfer',
      InsufficientBacking: 'error.insufficientBacking',
    };
    const data = e.data ?? e.info?.error?.data;
    let parsed = null;
    try { parsed = data ? new Interface(poolAbi).parseError(data) : null; }
    catch { /* Unknown provider error data. */ }
    if (parsed) return { labelKey: 'status.reverted' as const, messageKey: descriptions[parsed.name] ?? 'status.contractError' as const, params: { name: parsed.name } };
    return { labelKey: 'status.reverted' as const, messageKey: 'status.contractRejected' as const };
  }
  if (e.code === 'NETWORK_ERROR' || e.code === 'SERVER_ERROR') return { labelKey: 'status.networkError' as const, messageKey: 'status.networkErrorMessage' as const };
  return { labelKey: 'status.failed' as const, messageKey: 'status.unknown' as const, rawMessage: e.shortMessage ?? e.message };
}
