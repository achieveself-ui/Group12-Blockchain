import { useCallback, useEffect, useState } from 'react';
import {
  Activity, ArrowDownLeft, ArrowRight, ArrowUpRight, Check, ChevronDown,
  CircleAlert, Clock3, FileText, FlaskConical, LayoutDashboard, LockKeyhole,
  RefreshCw, Shield, ShieldCheck, Wallet, Zap,
} from 'lucide-react';
import type { BrowserProvider } from 'ethers';
import { expectedChainId, isConfigured, localTeachingMode } from './contracts/config';
import { t, type CopyKey, type Language } from './i18n';
import TeachingPanel from './TeachingPanel';
import {
  classifyError, deposit, displayAmount, inputAmount, PoolError, readSnapshot,
  redeem, requireNetwork, walletState,
  type Snapshot,
} from './services/pool';

type Page = 'overview' | 'deposit' | 'secure' | 'teaching' | 'compare' | 'report';
type Status = {
  labelKey: CopyKey;
  messageKey: CopyKey;
  params?: Record<string, string | number>;
  rawMessage?: string;
  hash?: string;
  tone: 'neutral' | 'good' | 'error';
};

const navigation: { id: Page; labelKey: CopyKey; icon: typeof Shield }[] = [
  { id: 'overview', labelKey: 'nav.overview', icon: LayoutDashboard },
  { id: 'deposit', labelKey: 'nav.deposit', icon: ArrowDownLeft },
  { id: 'secure', labelKey: 'nav.secure', icon: ShieldCheck },
  { id: 'teaching', labelKey: 'nav.teaching', icon: FlaskConical },
  { id: 'compare', labelKey: 'nav.compare', icon: Activity },
  { id: 'report', labelKey: 'nav.report', icon: FileText },
];

const pageDescriptions: Record<Page, CopyKey> = {
  overview: 'page.overview.description',
  deposit: 'page.deposit.description',
  secure: 'page.secure.description',
  teaching: 'page.teaching.description',
  compare: 'page.compare.description',
  report: 'page.report.description',
};

function shortened(address: string) { return `${address.slice(0, 6)}…${address.slice(-4)}`; }
function pretty(value: bigint | undefined, decimals = 18) {
  if (value === undefined) return '—';
  const [whole, fraction] = displayAmount(value, decimals).split('.');
  return `${whole.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}${fraction ? `.${fraction}` : ''}`;
}

function initialLanguage(): Language {
  try { return localStorage.getItem('defi-shield-language') === 'en' ? 'en' : 'zh'; }
  catch { return 'zh'; }
}

export default function App() {
  const [language, setLanguage] = useState<Language>(initialLanguage);
  const [page, setPage] = useState<Page>('overview');
  const [provider, setProvider] = useState<BrowserProvider | null>(null);
  const [account, setAccount] = useState('');
  const [chainId, setChainId] = useState<number>();
  const [snapshot, setSnapshot] = useState<Snapshot>();
  const [depositInput, setDepositInput] = useState('');
  const [redeemInput, setRedeemInput] = useState('');
  const [status, setStatus] = useState<Status>();
  const [busy, setBusy] = useState(false);

  const copy = (key: CopyKey, values?: Record<string, string | number>) => t(language, key, values);
  const connected = Boolean(account);
  const ready = connected && chainId === expectedChainId && isConfigured;
  const localTeachingAvailable = localTeachingMode && ready;

  useEffect(() => {
    document.documentElement.lang = language === 'zh' ? 'zh-CN' : 'en';
    document.title = t(language, 'title');
    try { localStorage.setItem('defi-shield-language', language); } catch { /* Storage may be blocked. */ }
  }, [language]);

  const refresh = useCallback(async (connect = false) => {
    try {
      const wallet = await walletState(connect);
      setProvider(wallet.provider);
      setAccount(wallet.account);
      setChainId(wallet.chainId);
      setSnapshot(undefined);
      if (wallet.account && wallet.chainId === expectedChainId && isConfigured) {
        setSnapshot(await readSnapshot(wallet.provider, wallet.account));
      }
      if (connect && wallet.chainId !== expectedChainId) requireNetwork(wallet.chainId);
      if (connect && !isConfigured) setStatus({ labelKey: 'status.config', messageKey: 'banner.config.message', tone: 'neutral' });
    } catch (error) {
      setStatus({ ...classifyError(error), tone: 'error' });
    }
  }, []);

  useEffect(() => {
    if (!window.ethereum) return;
    void refresh();
    const changed = () => { setStatus(undefined); void refresh(); };
    window.ethereum.on?.('accountsChanged', changed);
    window.ethereum.on?.('chainChanged', changed);
    return () => {
      window.ethereum?.removeListener?.('accountsChanged', changed);
      window.ethereum?.removeListener?.('chainChanged', changed);
    };
  }, [refresh]);

  async function switchNetwork() {
    if (!window.ethereum || busy) return;
    try {
      setBusy(true);
      await window.ethereum.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: `0x${expectedChainId.toString(16)}` }],
      });
      await refresh();
    } catch (error) {
      setStatus({ ...classifyError(error), tone: 'error' });
    } finally { setBusy(false); }
  }

  async function submit(action: 'deposit' | 'redeem') {
    if (!provider || !account || !snapshot || !ready || busy || snapshot.paused) return;
    try {
      const amount = inputAmount(action === 'deposit' ? depositInput : redeemInput, action === 'deposit' ? snapshot.assetDecimals : snapshot.shareDecimals);
      if (action === 'deposit' && amount > snapshot.assetBalance) throw new PoolError('error.lowAssetBalance');
      if (action === 'redeem' && amount > snapshot.shareBalance) throw new PoolError('error.lowShareBalance');
      setBusy(true);
      setStatus({ labelKey: 'status.wallet', messageKey: 'status.walletMessage', tone: 'neutral' });
      const onUpdate = (phase: 'wallet' | 'pending' | 'success', hash?: string) => {
        setStatus(phase === 'wallet'
          ? { labelKey: 'status.wallet', messageKey: 'status.walletOperation', tone: 'neutral' }
          : phase === 'pending'
            ? { labelKey: 'status.pending', messageKey: 'status.pendingMessage', hash, tone: 'neutral' }
            : { labelKey: 'status.success', messageKey: 'status.successRefreshing', hash, tone: 'good' });
      };
      if (action === 'deposit') await deposit(provider, account, amount, onUpdate);
      else await redeem(provider, account, amount, onUpdate);
      try {
        setSnapshot(await readSnapshot(provider, account));
        if (action === 'deposit') setDepositInput('');
        else setRedeemInput('');
        setStatus(previous => previous ? { ...previous, messageKey: 'status.successRefreshed' } : previous);
      } catch {
        setStatus(previous => previous ? { ...previous, messageKey: 'status.successReadFailed' } : previous);
      }
    } catch (error) {
      setStatus({ ...classifyError(error), tone: 'error' });
    } finally { setBusy(false); }
  }

  const networkLabel = chainId === 31337 ? copy('network.local') : chainId === 11155111 ? copy('network.sepolia') : chainId ? `Chain ID ${chainId}` : copy('network.disconnected');
  const targetNetwork = expectedChainId === 11155111 ? copy('network.sepolia') : `Chain ID ${expectedChainId}`;
  const assetSymbol = snapshot?.assetSymbol ?? 'TOKEN';
  const shareSymbol = snapshot?.shareSymbol ?? 'SHARE';
  const selectedNav = navigation.find(item => item.id === page);

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><span className="brand-icon"><Shield size={22} strokeWidth={2.3} /></span><span>DEFI<span className="brand-accent">SHIELD</span><small>LIQUIDITY SECURITY LAB</small></span></div>
      <div className="nav-label">{copy('nav.workspace')}</div>
      <nav aria-label={copy('nav.main')}>
        {navigation.filter(item => item.id !== 'teaching' || localTeachingAvailable).map(item =>
          <button key={item.id} className={`nav-item ${page === item.id ? 'active' : ''}`} onClick={() => setPage(item.id)}>
            <item.icon size={18} strokeWidth={1.8} />{copy(item.labelKey)}{page === item.id && <span className="nav-indicator" />}
          </button>)}
      </nav>
      <div className="sidebar-bottom"><div className="sidebar-note"><div className="note-icon"><LockKeyhole size={16} /></div><strong>{copy('sidebar.lab')}</strong><p>{copy('sidebar.note')}</p></div><div className="sidebar-version"><span className="live-dot" />{copy('sidebar.version')}</div></div>
    </aside>

    <main className="main">
      <header className="topbar">
        <div className="breadcrumb">{copy('nav.workspace')} <span>/</span> <strong>{selectedNav && copy(selectedNav.labelKey)}</strong></div>
        <div className="top-actions">
          <button type="button" className="language-button" aria-label={copy('languageSwitch')} title={copy('languageSwitch')} onClick={() => setLanguage(current => current === 'zh' ? 'en' : 'zh')}>{language === 'zh' ? 'EN' : '中文'}</button>
          <span className={`network-pill ${connected && chainId !== expectedChainId ? 'warning' : ''}`}><span className="live-dot" />{networkLabel}</span>
          <button className="wallet-button" onClick={() => void refresh(true)}><Wallet size={17} />{account ? shortened(account) : copy('wallet.connect')}<ChevronDown size={14} /></button>
        </div>
      </header>
      <div className="content">
        <div className="eyebrow"><span className="eyebrow-line" /> DEFI SHIELD / SECURITY LAB</div>
        <div className="page-heading"><div><h1>{page === 'overview' ? copy('page.overview.title') : selectedNav && copy(selectedNav.labelKey)}</h1><p>{copy(pageDescriptions[page])}</p></div><span className="version-badge"><ShieldCheck size={15} /> SECURE POOL · V2</span></div>
        {!isConfigured && <div className="banner"><CircleAlert size={18} /><div><strong>{copy('banner.config.title')}</strong><span>{copy('banner.config.message')}</span></div></div>}
        {connected && chainId !== expectedChainId && <div className="banner warning"><CircleAlert size={18} /><div><strong>{copy('banner.network.title')}</strong><span>{copy('banner.network.message', { network: networkLabel, target: targetNetwork })}</span></div><button className="switch-button" disabled={busy} onClick={() => void switchNetwork()}>{copy('banner.network.button', { target: expectedChainId === 11155111 ? 'Sepolia' : `Chain ID ${expectedChainId}` })}</button></div>}
        {snapshot?.paused && <div className="banner warning"><LockKeyhole size={18} /><div><strong>{copy('banner.paused.title')}</strong><span>{copy('banner.paused.message')}</span></div></div>}

        {(page === 'overview' || page === 'deposit' || page === 'secure') && <>
          <div className="stats">
            <Metric icon={Wallet} label={copy('metric.asset')} value={pretty(snapshot?.assetBalance, snapshot?.assetDecimals)} unit={assetSymbol} detail={copy('metric.availableBalance')} />
            <Metric icon={Activity} label={copy('metric.pool')} value={pretty(snapshot?.poolBalance, snapshot?.assetDecimals)} unit={assetSymbol} detail="getPoolBalance()" />
            <Metric icon={ShieldCheck} label={copy('metric.myShares')} value={pretty(snapshot?.shareBalance, snapshot?.shareDecimals)} unit={shareSymbol} detail={copy('metric.balanceOfAccount')} />
            <Metric icon={Zap} label={copy('metric.totalShares')} value={pretty(snapshot?.totalSupply, snapshot?.shareDecimals)} unit={shareSymbol} detail="totalSupply()" />
          </div>
          <div className="dashboard-grid">
            <section className="panel trade-panel">
              <div className="panel-heading"><div><span className="panel-kicker">{copy('trade.kicker')}</span><h2>{copy('trade.title')}</h2></div><span className={`status-chip ${snapshot?.paused ? 'paused' : ''}`}><span className="live-dot" />{copy(snapshot ? snapshot.paused ? 'trade.paused' : 'trade.running' : 'trade.waitingConnection')}</span></div>
              <div className="tabs"><button className={page !== 'secure' ? 'selected' : ''} onClick={() => setPage('deposit')}><ArrowDownLeft size={17} /> {copy('trade.depositTab')}</button><button className={page === 'secure' ? 'selected' : ''} onClick={() => setPage('secure')}><ArrowUpRight size={17} /> {copy('trade.redeemTab')}</button></div>
              {page === 'secure'
                ? <div className="form"><label htmlFor="redeemAmount">{copy('trade.redeemAmount')} <span>{copy('trade.available', { amount: pretty(snapshot?.shareBalance, snapshot?.shareDecimals), symbol: shareSymbol })}</span></label><div className="amount-box"><input id="redeemAmount" inputMode="decimal" placeholder="0.00" value={redeemInput} onChange={event => setRedeemInput(event.target.value)} /><span>{shareSymbol}</span></div><div className="form-help"><span>{copy('trade.exchangeRate')}</span><strong>{copy('trade.exchangeRatio', { symbol: shareSymbol, asset: assetSymbol })}</strong></div><button className="primary-button" disabled={!ready || !snapshot || snapshot.paused || busy} onClick={() => void submit('redeem')}>{copy(busy ? 'trade.processing' : !connected ? 'trade.connectFirst' : 'trade.redeem')}<ArrowRight size={18} /></button></div>
                : <div className="form"><label htmlFor="depositAmount">{copy('trade.depositAmount')} <span>{copy('trade.available', { amount: pretty(snapshot?.assetBalance, snapshot?.assetDecimals), symbol: assetSymbol })}</span></label><div className="amount-box"><input id="depositAmount" inputMode="decimal" placeholder="0.00" value={depositInput} onChange={event => setDepositInput(event.target.value)} /><span>{assetSymbol}</span></div><div className="form-help"><span>{copy('trade.mintRule')}</span><strong>{copy('trade.mintRatio')}</strong></div><button className="primary-button" disabled={!ready || !snapshot || snapshot.paused || busy} onClick={() => void submit('deposit')}>{copy(busy ? 'trade.processing' : !connected ? 'trade.connectFirst' : 'trade.approveDeposit')}<ArrowRight size={18} /></button></div>}
              <p className="under-form"><LockKeyhole size={14} /> {copy('trade.note')}</p>
            </section>
            <section className="panel activity-panel">
              <div className="panel-heading"><div><span className="panel-kicker">{copy('activity.kicker')}</span><h2>{copy('activity.title')}</h2></div><button className="icon-button" title={copy('activity.refresh')} aria-label={copy('activity.refresh')} disabled={!ready || busy} onClick={() => void refresh()}><RefreshCw size={17} /></button></div>
              <div className="activity-body"><div className={`activity-icon ${status?.tone ?? ''}`}>{status?.tone === 'good' ? <Check size={24} /> : status?.tone === 'error' ? <CircleAlert size={24} /> : <Clock3 size={24} />}</div><h3>{copy(status?.labelKey ?? 'activity.emptyTitle')}</h3><p>{status ? status.rawMessage ?? copy(status.messageKey, status.params) : copy('activity.emptyMessage')}</p>{status?.hash && <code title={status.hash}>{copy('activity.hash')} {shortened(status.hash)}</code>}</div>
              <div className="activity-footer"><span>{copy('activity.source')}</span><strong><span className="live-dot" /> {copy('activity.contract')}</strong></div>
            </section>
          </div>
          <div className="footnote"><ShieldCheck size={18} /><span>{copy('footnote')}</span></div>
        </>}
        {page === 'teaching' && (localTeachingAvailable
          ? <TeachingPanel language={language} snapshot={snapshot} onRefresh={() => void refresh()} />
          : <SectionPlaceholder icon={LockKeyhole} badge="LOCAL ONLY" heading={copy('teaching.unavailable')} description={copy('teaching.unavailableDescription')} language={language} />)}
        {page === 'compare' && <SectionPlaceholder icon={Activity} badge="ON-CHAIN COMPARISON" heading={copy('compare.waiting')} description={copy('compare.description')} language={language} />}
        {page === 'report' && <section className="panel placeholder">
          <div className="placeholder-icon"><FileText size={29} /></div>
          <h2>{copy('report.title')}</h2>
          <p>{copy('report.description')}</p>
          <a className="report-link" href={`${import.meta.env.BASE_URL}evidence/secure-pool-test.txt`} target="_blank" rel="noopener noreferrer">{copy('report.open')}</a>
        </section>}
      </div>
    </main>
  </div>;
}

function Metric({ icon: Icon, label, value, unit, detail }: { icon: typeof Shield; label: string; value: string; unit: string; detail: string }) {
  return <article className="metric"><div className="metric-top"><span>{label}</span><Icon size={19} strokeWidth={1.8} /></div><div className="metric-value">{value}<span> {unit}</span></div><div className="metric-detail">{detail}</div></article>;
}

function SectionPlaceholder({ icon: Icon, badge, heading, description, language }: { icon: typeof Shield; badge: string; heading: string; description: string; language: Language }) {
  return <section className="panel placeholder"><div className="placeholder-icon"><Icon size={29} /></div><span className="panel-kicker">{badge}</span><h2>{heading}</h2><p>{description}</p><div className="placeholder-rule"><span>{t(language, 'placeholder.pending')}</span><span>·</span><span>{t(language, 'placeholder.noSample')}</span></div></section>;
}
