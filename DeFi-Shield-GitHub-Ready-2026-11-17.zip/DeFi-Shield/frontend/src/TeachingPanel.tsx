import { RefreshCw } from 'lucide-react';
import { t, type Language } from './i18n';
import { displayAmount, type Snapshot } from './services/pool';

type Props = {
  language: Language;
  snapshot?: Snapshot;
  onRefresh: () => void;
};

export default function TeachingPanel({ language, snapshot, onRefresh }: Props) {
  const coverage = !snapshot
    ? 'teaching.pending'
    : snapshot.poolBalance >= snapshot.totalSupply
      ? 'teaching.covered'
      : 'teaching.undercovered';

  return (
    <section className="panel teaching-panel">
      <div className="panel-heading">
        <h2>{t(language, 'teaching.title')}</h2>
        <button
          className="icon-button"
          type="button"
          aria-label={t(language, 'teaching.refresh')}
          onClick={onRefresh}
        >
          <RefreshCw size={17} />
        </button>
      </div>
      <p>{t(language, 'teaching.description')}</p>
      <dl className="teaching-metrics">
        <div>
          <dt>{t(language, 'metric.pool')}</dt>
          <dd>{snapshot ? `${displayAmount(snapshot.poolBalance, snapshot.assetDecimals)} ${snapshot.assetSymbol}` : '—'}</dd>
        </div>
        <div>
          <dt>{t(language, 'metric.totalShares')}</dt>
          <dd>{snapshot ? `${displayAmount(snapshot.totalSupply, snapshot.shareDecimals)} ${snapshot.shareSymbol}` : '—'}</dd>
        </div>
        <div>
          <dt>{t(language, 'metric.myShares')}</dt>
          <dd>{snapshot ? `${displayAmount(snapshot.shareBalance, snapshot.shareDecimals)} ${snapshot.shareSymbol}` : '—'}</dd>
        </div>
        <div>
          <dt>{t(language, 'teaching.coverage')}</dt>
          <dd role="status">{t(language, coverage)}</dd>
        </div>
      </dl>
      <div className="teaching-notes">
        <article>
          <h3>{t(language, 'teaching.accounting')}</h3>
          <p>{t(language, 'teaching.accountingNote')}</p>
        </article>
        <article>
          <h3>{t(language, 'teaching.ownership')}</h3>
          <p>{t(language, 'teaching.ownershipNote')}</p>
        </article>
      </div>
    </section>
  );
}
