import { isAddress } from 'ethers';
import { DEPLOYMENTS, HARDHAT_CHAIN_ID, SEPOLIA_CHAIN_ID } from './deployments';

export const localTeachingMode = import.meta.env.MODE === 'hardhat';
export const expectedChainId = localTeachingMode ? HARDHAT_CHAIN_ID : SEPOLIA_CHAIN_ID;
const expectedDeployment = DEPLOYMENTS[expectedChainId];

export const poolAddress = import.meta.env.VITE_SECURE_POOL_ADDRESS || expectedDeployment?.securePool || '';
export const assetAddress = import.meta.env.VITE_TEST_TOKEN_ADDRESS || expectedDeployment?.assetToken || '';
export const shareAddress = import.meta.env.VITE_SHARE_TOKEN_ADDRESS || expectedDeployment?.shareToken || '';
export const isConfigured = [poolAddress, assetAddress, shareAddress].every(isAddress);

export const poolAbi = [
  'function deposit(uint256 assets)',
  'function redeem(uint256 shares)',
  'function getPoolBalance() view returns (uint256)',
  'function shareToken() view returns (address)',
  'function assetToken() view returns (address)',
  'function initialized() view returns (bool)',
  'function paused() view returns (bool)',
  'error AlreadyInitialized()',
  'error NotInitialized()',
  'error InvalidToken()',
  'error InvalidShareToken()',
  'error UnsupportedDecimals()',
  'error ZeroAmount()',
  'error InsufficientShares()',
  'error InsufficientPoolAssets()',
  'error UnsupportedAssetTransfer()',
  'error InsufficientBacking()',
  'event Deposited(address indexed user, uint256 assets, uint256 shares)',
  'event Redeemed(address indexed user, uint256 shares, uint256 assets)',
] as const;

export const tokenAbi = [
  'function balanceOf(address owner) view returns (uint256)',
  'function allowance(address owner, address spender) view returns (uint256)',
  'function approve(address spender, uint256 amount) returns (bool)',
  'function totalSupply() view returns (uint256)',
  'function decimals() view returns (uint8)',
  'function symbol() view returns (string)',
] as const;
