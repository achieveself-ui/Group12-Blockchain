# DeFi Shield Frontend

The React and TypeScript frontend uses ethers.js to connect MetaMask to SecurePool, TestToken and PoolShareToken. The navigation and transaction feedback support Chinese and English.

## Run from the project root

Follow the [main README](../README.md) to install the two sets of dependencies. Run `npm run dev:local` after deploying to Hardhat, or `npm run dev:sepolia` for the team's Sepolia addresses.

| Frontend mode | Chain ID | Address configuration |
| --- | --- | --- |
| `hardhat` | 31337 | `npm run deploy:local` generates `.env.hardhat.local`. |
| `sepolia` | 11155111 | Defaults are in `src/contracts/deployments.ts`. `npm run deploy:sepolia` generates `.env.sepolia.local` for a new deployment. |

If you have an existing deployment, set `VITE_TEST_TOKEN_ADDRESS`, `VITE_SECURE_POOL_ADDRESS` and `VITE_SHARE_TOKEN_ADDRESS` together in the mode-specific environment file. Restart Vite after changing addresses. The frontend checks the chain ID, deployed contract code, initialization, and the pool's asset and share token bindings.

## Source files

- `src/App.tsx` holds wallet state, balance displays, deposit and redemption views, and transaction feedback.
- `src/services/pool.ts` implements contract reads, conditional approval, deposit, redeem, and token unit conversion.
- `src/contracts/config.ts` defines the ABIs and selects each mode's addresses.
- `src/i18n.ts` contains the Chinese and English interface text.
- `src/TeachingPanel.tsx` displays live SecurePool backing data in Hardhat mode.
- `public/evidence/secure-pool-test.txt` contains the actual regression test output linked in the interface.
