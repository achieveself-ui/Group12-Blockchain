// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

import {TestToken} from "../TestToken.sol";

/// @notice Fixture for the backing check in the SecurePool regression suite.
contract BackingLossTestToken is TestToken {
    constructor() {
        require(block.chainid == 31337, "Hardhat test fixture only");
    }

    function burnForTest(address account, uint256 amount) external onlyOwner {
        _burn(account, amount);
    }
}
