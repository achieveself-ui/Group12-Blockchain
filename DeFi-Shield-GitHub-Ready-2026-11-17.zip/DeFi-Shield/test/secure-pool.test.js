const { expect } = require('chai');
const { ethers } = require('hardhat');

// E/B deployed-source version. Each test deploys fresh contracts on Hardhat's
// in-memory chain; it never changes the user's localhost demo deployment.
async function fixture() {
  const [owner, alice, bob] = await ethers.getSigners();
  const pool = await ethers.deployContract('SecurePool');
  const asset = await ethers.deployContract('TestToken');
  const share = await ethers.deployContract('PoolShareToken', [await pool.getAddress()]);
  await pool.initialize(await asset.getAddress(), await share.getAddress());
  for (const person of [alice, bob]) {
    await asset.mint(person.address, 1000n);
    await asset.connect(person).approve(await pool.getAddress(), 1000n);
  }
  return { owner, alice, bob, pool, asset, share };
}

async function state({ pool, asset, share, alice }) {
  return [await asset.balanceOf(alice.address), await share.balanceOf(alice.address),
    await share.totalSupply(), await pool.getPoolBalance(), await asset.balanceOf(await pool.getAddress())];
}

describe('E version: SecurePool', function () {
  it('deposits 1:1, emits event, and updates all balances', async function () {
    const f = await fixture();
    await expect(f.pool.connect(f.alice).deposit(100n)).to.emit(f.pool, 'Deposited').withArgs(f.alice.address, 100n, 100n);
    expect(await state(f)).to.deep.equal([900n, 100n, 100n, 100n, 100n]);
  });
  it('redeems 1:1, emits event, and updates all balances', async function () {
    const f = await fixture();
    await f.pool.connect(f.alice).deposit(100n);
    await expect(f.pool.connect(f.alice).redeem(40n)).to.emit(f.pool, 'Redeemed').withArgs(f.alice.address, 40n, 40n);
    expect(await state(f)).to.deep.equal([940n, 60n, 60n, 60n, 60n]);
  });
  it('fully redeems to zero', async function () {
    const f = await fixture();
    await f.pool.connect(f.alice).deposit(100n);
    await f.pool.connect(f.alice).redeem(100n);
    expect(await state(f)).to.deep.equal([1000n, 0n, 0n, 0n, 0n]);
  });
  it('keeps another depositor balance unchanged', async function () {
    const f = await fixture();
    await f.pool.connect(f.alice).deposit(100n);
    await f.pool.connect(f.bob).deposit(200n);
    await f.pool.connect(f.alice).redeem(50n);
    expect(await f.share.balanceOf(f.bob.address)).to.equal(200n);
    expect(await f.pool.getPoolBalance()).to.equal(250n);
  });
  it('rejects zero deposit with no state change', async function () {
    const f = await fixture(); const before = await state(f);
    await expect(f.pool.connect(f.alice).deposit(0n)).to.be.revertedWithCustomError(f.pool, 'ZeroAmount');
    expect(await state(f)).to.deep.equal(before);
  });
  it('rejects zero redeem with no state change', async function () {
    const f = await fixture(); await f.pool.connect(f.alice).deposit(100n); const before = await state(f);
    await expect(f.pool.connect(f.alice).redeem(0n)).to.be.revertedWithCustomError(f.pool, 'ZeroAmount');
    expect(await state(f)).to.deep.equal(before);
  });
  it('rejects deposit above wallet balance', async function () {
    const f = await fixture(); const before = await state(f);
    await expect(f.pool.connect(f.alice).deposit(1001n)).to.be.reverted;
    expect(await state(f)).to.deep.equal(before);
  });
  it('rejects deposit without allowance', async function () {
    const f = await fixture(); await f.asset.connect(f.alice).approve(await f.pool.getAddress(), 0n);
    const before = await state(f);
    await expect(f.pool.connect(f.alice).deposit(1n)).to.be.reverted;
    expect(await state(f)).to.deep.equal(before);
  });
  it('rejects redeem above owned shares', async function () {
    const f = await fixture(); await f.pool.connect(f.alice).deposit(100n); const before = await state(f);
    await expect(f.pool.connect(f.alice).redeem(101n)).to.be.revertedWithCustomError(f.pool, 'InsufficientShares');
    expect(await state(f)).to.deep.equal(before);
  });
  it('rejects redeem when pool assets are insufficient', async function () {
    // The test fixture simulates an unexpected loss of backing.
    const [owner, alice] = await ethers.getSigners();
    const pool = await ethers.deployContract('SecurePool');
    const asset = await ethers.deployContract('BackingLossTestToken');
    const share = await ethers.deployContract('PoolShareToken', [await pool.getAddress()]);
    await pool.initialize(await asset.getAddress(), await share.getAddress());
    await asset.mint(alice.address, 100n);
    await asset.connect(alice).approve(await pool.getAddress(), 100n);
    await pool.connect(alice).deposit(100n);
    await asset.connect(owner).burnForTest(await pool.getAddress(), 1n);
    await expect(pool.connect(alice).redeem(100n)).to.be.revertedWithCustomError(pool, 'InsufficientPoolAssets');
    expect(await share.balanceOf(alice.address)).to.equal(100n);
    expect(await pool.getPoolBalance()).to.equal(99n);
  });
  it('only owner may pause or unpause', async function () {
    const f = await fixture();
    await expect(f.pool.connect(f.alice).pause()).to.be.reverted;
    expect(await f.pool.paused()).to.equal(false);
    await f.pool.pause();
    await expect(f.pool.connect(f.alice).unpause()).to.be.reverted;
    expect(await f.pool.paused()).to.equal(true);
  });
  it('blocks deposit and redeem while paused, permits reads, then resumes', async function () {
    const f = await fixture(); await f.pool.connect(f.alice).deposit(100n);
    await f.pool.pause(); const before = await state(f);
    await expect(f.pool.connect(f.alice).deposit(1n)).to.be.reverted;
    await expect(f.pool.connect(f.alice).redeem(1n)).to.be.reverted;
    expect(await state(f)).to.deep.equal(before);
    await f.pool.unpause(); await f.pool.connect(f.alice).redeem(1n);
    expect(await f.pool.paused()).to.equal(false);
  });
  it('rejects a second initialization', async function () {
    const f = await fixture(); const old = await f.pool.shareToken();
    await expect(f.pool.initialize(await f.asset.getAddress(), old)).to.be.revertedWithCustomError(f.pool, 'AlreadyInitialized');
    expect(await f.pool.shareToken()).to.equal(old);
  });
  it('only pool may mint or burn share tokens', async function () {
    const f = await fixture();
    await expect(f.share.connect(f.alice).mint(f.alice.address, 1n)).to.be.revertedWithCustomError(f.share, 'OnlyPool');
    await expect(f.share.connect(f.alice).burn(f.alice.address, 1n)).to.be.revertedWithCustomError(f.share, 'OnlyPool');
    expect(await f.share.totalSupply()).to.equal(0n);
  });
  it('deposits one base unit exactly, and rejects uint256 max redeem', async function () {
    const f = await fixture(); await f.pool.connect(f.alice).deposit(1n);
    expect(await state(f)).to.deep.equal([999n, 1n, 1n, 1n, 1n]);
    const before = await state(f);
    await expect(f.pool.connect(f.alice).redeem(ethers.MaxUint256)).to.be.reverted;
    expect(await state(f)).to.deep.equal(before);
  });
});
